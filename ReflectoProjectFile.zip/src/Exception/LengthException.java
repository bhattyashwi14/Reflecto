package Exception;
public class LengthException extends RuntimeException {
    public LengthException(String message)
    {
        super(message);
    }
}
